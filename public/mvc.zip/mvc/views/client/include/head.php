<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>PHUOCMG</title>
    <base href="<?=base?>">
    <link href="public/client/csss/bootstrap.min.css" rel="stylesheet">
    <link href="public/client/csss/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="public/client/fontawesome-free-5.15.3/css/all.min.css">
    <link href="public/client/csss/prettyPhoto.css" rel="stylesheet">
    <link href="public/client/csss/price-range.css" rel="stylesheet">
    <link href="public/client/csss/animate.css" rel="stylesheet">
	<link href="public/client/csss/main.css" rel="stylesheet">
	<link href="public/client/csss/responsive.css" rel="stylesheet">
    <link href="public/client/csss/home.css" rel="stylesheet">
    <link rel="stylesheet" href="public/client/csss/rps_ipad.css">
    <link rel="stylesheet" href="public/client/csss/rps_mobile.css">
    <base href="<?=base?>">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="public/client/images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="public/client/images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="public/client/images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="public/client/images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="public/client/images/ico/apple-touch-icon-57-precomposed.png">
    <!--jquery-->
    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <link href="public/client/csss/cart.css" rel="stylesheet">
    <link href="public/client/csss/info.css" rel="stylesheet">
    <script src="../../../../public/client/js/trung-font-icon.js"></script>
</head><!--/head-->
