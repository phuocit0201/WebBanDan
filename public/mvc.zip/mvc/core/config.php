<?php
    define("base","https://dichvufb76.ml/");
?>